package com.ssafy.rent;

import com.ssafy.rent.view.HomeInfoView;

public class Main {
	
	// 허찬영2
	public static void main(String[] args) {
		new HomeInfoView();			
	}
}
