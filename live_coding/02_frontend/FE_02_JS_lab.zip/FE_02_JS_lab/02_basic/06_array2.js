// 02_basic/06_array2.js
// 배열의 활용
const curriculum = ["frontend", "C", "backend", "Spring"];

// TODO: 다음의 요청 사항을 만족시켜보자.
//  frontend 앞에 배운 과정을 추가하고 출력해보자.
//  Spring 뒤에 배울 과정을 추가하고 출력해보자.
//  C를 삭제하고 출력해보자.

// END
