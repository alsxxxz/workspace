// 02_basic/11_condition.js
let userName;

if (userName) {
  console.log("사용자 이름이 있습니다.");
} else {
  console.log("사용자 이름이 없습니다.");
}

let num = Number.parseInt(Math.random() * 2);
console.log("생성된 숫자는? ", num);
let numStatus;
//TODO: 01.다양한 방식으로 num이 짝수인지, 홀수인지 판별하는 코드를 작성해보자.

// END
