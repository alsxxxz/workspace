import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.StringTokenizer;

/**
 * @author TaeHee
 */
public class Solution_M5648_원자소멸시뮬레이션_조합_김태희 {

	static int N;
	static Atom[] list;

	public static void main(String[] args) throws Exception {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int TC = Integer.parseInt(br.readLine().trim());
		for (int tc = 1; tc <= TC; ++tc) {
			N = Integer.parseInt(br.readLine());
			StringTokenizer st = null;
			list = new Atom[N];
			for (int i = 0; i < N; ++i) {
				st = new StringTokenizer(br.readLine(), " ");
				// 만약 시간을 정수로 처리하고 싶으면 *2배 처리
				int x = Integer.parseInt(st.nextToken()) * 2; // x좌표
				int y = Integer.parseInt(st.nextToken()) * 2; // y좌표
				int d = Integer.parseInt(st.nextToken()); // 방향
				int e = Integer.parseInt(st.nextToken()); // 에너지

				list[i] = new Atom(x, y, d, e);
			}
			System.out.println("#" + tc + " " + makeBoomPair());
		} // end TC
	}

	// x좌표 기준 오름차순 정렬, 같다면 y좌표 기준 오름차순 정렬
	// 정렬 후 앞쪽부터 조합을 만드므로 원자1의 x좌표가 항상 같거나 작음을 보장
	private static int makeBoomPair() {
		Arrays.sort(list);
		ArrayList<Pair> boomPairs = new ArrayList<>();
		for (int i = 0; i < N; ++i) { // 조합될 원자1
			for (int j = i + 1; j < N; ++j) { // 조합될 원자2
				Atom a = list[i], b = list[j];
				// 수직선에서 만날때(x좌표가 같다.)
				if (a.x == b.x) {
					if (a.dir == 0 && b.dir == 1) {
						boomPairs.add(new Pair(i, j, Math.abs(a.y - b.y) / 2));
					}
				}
				// 수평선에서 만날때(y좌표가 같다.)
				if (a.y == b.y) {
					if (a.dir == 3 && b.dir == 2) {
						boomPairs.add(new Pair(i, j, Math.abs(a.x - b.x) / 2));
					}
				}
				// /라인에 있는 애들이 만날때 : 행과 열의 차이가 일정
				if (a.x - a.y == b.x - b.y) {
					if (a.dir == 3 && b.dir == 1 || a.dir == 0 && b.dir == 2) {
						boomPairs.add(new Pair(i, j, Math.abs(a.x - b.x)));
					}
				}
				// \라인에 있는 원자들이 만날때 : 행과 열의 합이 일정
				if (a.x + a.y == b.x + b.y) {
					if (a.dir == 1 && b.dir == 2 || a.dir == 3 && b.dir == 0) {
						boomPairs.add(new Pair(i, j, Math.abs(a.x - b.x)));
					}
				}
			} // end j for
		} // end i for
		return getTotalEnergy(boomPairs);
	}

	private static int getTotalEnergy(ArrayList<Pair> boomPairs) {
		Collections.sort(boomPairs, (a, b) -> a.time <= b.time ? -1 : 1); // 원자조합쌍의 폭발시간 기준 오름차순 정렬
		final int INF = Integer.MAX_VALUE;

		int boomTimes[] = new int[N]; // 각 원자들이 폭발하는 가장 빠른 시간 기록
		Arrays.fill(boomTimes, INF); // 최대값으로 초기화
		int sum = 0;
		for (Pair p : boomPairs) { // 터질 가능성의 조합을 하나씩 꺼내어 처리
			// 지금 원자 조합이 터지는 시간보다 둘 중 하나라도 먼저 터졌으면 이 조합의 경우는 폭발 불가
			// INF로 초기값 세팅 후 빠른 시간으로 충돌하는 쌍부터 처리하므로 터지지 않았는지
			// 동일시간인지 체크 가능
			if (boomTimes[p.i] < p.time || boomTimes[p.j] < p.time)
				continue;

			if (boomTimes[p.i] == INF) { // 안터졌다면
				boomTimes[p.i] = p.time;
				sum += list[p.i].e;
			}
			if (boomTimes[p.j] == INF) { // 안터졌다면
				boomTimes[p.j] = p.time;
				sum += list[p.j].e;
			}
		}
		return sum;
	}

	static class Atom implements Comparable<Atom> {
		int x, y, dir, e;

		public Atom(int x, int y, int dir, int e) {
			this.x = x;
			this.y = y;
			this.dir = dir;
			this.e = e;
		}

		@Override
		public int compareTo(Atom o) {
			int diff = Integer.compare(this.x, o.x);
			return diff != 0 ? diff : Integer.compare(this.y, o.y);
		}
	}

	static class Pair {
		int i, j;
		int time;

		public Pair(int i, int j, int time) {
			this.i = i;
			this.j = j;
			this.time = time;
		}
	}
}