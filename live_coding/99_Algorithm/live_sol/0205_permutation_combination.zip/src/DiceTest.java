import java.util.Arrays;
import java.util.Scanner;

public class DiceTest {

	private static boolean[] isSelected;
	private static int numbers[],N,totalCnt; 
	
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int mode = sc.nextInt(); // 주사위 던지기 모드 1~4
		N = sc.nextInt(); // 주사위 던지는 횟수(N<=6)
		totalCnt = 0;
		
		numbers = new int[N];
		
		switch (mode) {
		case 1: // 중복 순열 
			dice1(0);
			break;
		case 2: // 순열
			isSelected = new boolean[7]; // 인덱스 : 주사위 눈의수
			dice2(0);
			break;
		case 3: // 중복조합
			dice3(0,1);
			break;
		case 4: // 조합
			dice4(0,1);
			break;			
		default:
			break;
		}
		System.out.println("총 경우의 수 : "+totalCnt);
	}
	
	
	public static void dice1(int cnt) { // 중복 순열 : 중복된 수를 허용 (중복 관리 필요 없음 )
		if(cnt == N) {
			++totalCnt;
			System.out.println(Arrays.toString(numbers));
			return;
		}
		
		for (int i = 1; i <= 6; i++) {// 1 or 2 or 3,4,5,6,
			numbers[cnt] = i;
			dice1(cnt+1);
		}
	}
	public static void dice2(int cnt) { // 순열 : 중복된 수를 허용 하지 않음(중복 관리 필요)
		if(cnt == N) {
			++totalCnt;
			System.out.println(Arrays.toString(numbers));
			return;
		}
		
		for (int i = 1; i <= 6; i++) {// 1 or 2 or 3,4,5,6,
			// 중복 체크
			if(isSelected[i]) continue;
			isSelected[i] = true;
			numbers[cnt] = i;
			dice2(cnt+1);
			isSelected[i] = false;
		}
	}

	public static void dice3(int cnt, int start) { // 중복 조합 
		if(cnt == N) {
			++totalCnt;
			System.out.println(Arrays.toString(numbers));
			return;
		}
		
		for (int i = start; i <= 6; i++) {
			numbers[cnt] = i;
			dice3(cnt+1, i);
		}
	}
	
	public static void dice4(int cnt, int start) { // 조합 
		if(cnt == N) {
			++totalCnt;
			System.out.println(Arrays.toString(numbers));
			return;
		}
		
		for (int i = start; i <= 6; i++) {
			numbers[cnt] = i;
			dice4(cnt+1, i+1);
		}
	}
}














