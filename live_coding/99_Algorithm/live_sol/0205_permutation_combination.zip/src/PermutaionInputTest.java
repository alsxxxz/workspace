import java.util.Arrays;
import java.util.Scanner;

public class PermutaionInputTest {
	
	private static boolean[] isSelected;
	private static int numbers[],input[], N,R; 
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt(); // 원소의 크기
		R = sc.nextInt();
		
		input = new int[N]; // 입력된 원소들의 배열 
		isSelected = new boolean[N]; // 인덱스에 해당하는 수가 선택되었는지 여부
		numbers = new int[R]; // 선택된 수들이 저장되는 배열
		
		for (int i = 0; i < N; i++) {
			input[i] = sc.nextInt();
		}
		
		permutation(0);
	}

	public static void permutation(int cnt) { // 순열 : 중복된 수를 허용 하지 않음(중복 관리 필요)
		if(cnt == R) {  // R==N: nPn
			System.out.println(Arrays.toString(numbers));
			return;
		}
		
		for (int i = 0; i < N; i++) {
			// 중복 체크
			if(isSelected[i]) continue;
			isSelected[i] = true;
			numbers[cnt] = input[i];
			permutation(cnt+1);
			isSelected[i] = false;
		}
	}
}
