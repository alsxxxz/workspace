import java.util.ArrayDeque;
import java.util.Queue;

public class QueueMyChewTest {

	public static void main(String[] args) {

		int N = 20; // 현재 마이쮸 개수
		int person = 1; // 대기열에 들어갈 다음 사람의 번호
		
		Queue<int[]> queue = new ArrayDeque<>();
		queue.offer(new int[] {person,1});
		
		while(N>0) {
			int[] p = queue.poll();
			int availCnt = (N>=p[1])?p[1]:N; 
			N -= availCnt;
			if(N==0) { // 마지막 마이쮸를 가져가는 사람
				System.out.println(p[0]+"번 사람이 마지막 마이쮸를 가져갑니다. 가져간 개수 : "+availCnt);
			}else { // 마지막 마이쮸를 가져가지 않는 사람
				System.out.println(p[0]+"번 사람이 마이쮸를 가져갑니다. 가져간 개수 : "+availCnt);
				++p[1]; // 다음에는 마이쮸 +1개 만큼 더 받기
				queue.offer(p);
				queue.offer(new int[] {++person, 1});
			}
		}
		
	}

}
