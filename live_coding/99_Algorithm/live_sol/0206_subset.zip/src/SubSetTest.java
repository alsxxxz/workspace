import java.util.Scanner;

public class SubSetTest {

	static int N, input[], totalCnt;
	static boolean[] isSelected;
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		N = sc.nextInt(); // 원소 수
		int targetSum = sc.nextInt();
		
		input = new int[N];
		isSelected = new boolean[N]; // 기본값 : false
		
		for (int i = 0; i < N; i++) {
			input[i] = sc.nextInt();
		}
		
//		makeSubSet(0);
		makeSubSetSum(0, 0, targetSum);
		System.out.println("모든 경우의 수 : "+totalCnt);
	}
	
	public static void makeSubSet(int cnt) { // 원소 관점으로 처리, cnt:앞쪽까지 고려한 원소수  
		
		if(cnt == N) {
			++totalCnt;
			for (int i = 0; i < N; i++) {
				System.out.print((isSelected[i]?input[i]:"X")+"\t");
			}
			System.out.println();
			return;
		}
		
		// 해당 원소를 부분집합 구성에 넣기
		isSelected[cnt] = true;
		makeSubSet(cnt+1);
		// 해당 원소를 부분집합 구성에 넣지 않기
		isSelected[cnt] = false;
		makeSubSet(cnt+1);
		
	}
	
	public static void makeSubSetSum(int cnt, int pickCnt, int targetSum) { // 원소 관점으로 처리, cnt:앞쪽까지 고려한 원소수  
		
		if(cnt == N) {
			int sum = 0;
			for (int i = 0; i < N; i++) {
				if(isSelected[i]) sum += input[i];
			}
			if(pickCnt>0 && targetSum == sum) ++totalCnt;
			return;
		}
		
		// 해당 원소를 부분집합 구성에 넣기
		isSelected[cnt] = true;
		makeSubSetSum(cnt+1, pickCnt+1, targetSum);
		// 해당 원소를 부분집합 구성에 넣지 않기
		isSelected[cnt] = false;
		makeSubSetSum(cnt+1, pickCnt, targetSum);
		
	}

	public static void makeSubSetSum2(int cnt, int pickCnt, int sum, int targetSum) { // 원소 관점으로 처리, cnt:앞쪽까지 고려한 원소수  
		
		if(cnt == N) {
			if(pickCnt>0 && targetSum == sum) ++totalCnt;
			return;
		}
		
		// 해당 원소를 부분집합 구성에 넣기
		isSelected[cnt] = true;
		makeSubSetSum2(cnt+1, pickCnt+1, sum+input[cnt] , targetSum);
		// 해당 원소를 부분집합 구성에 넣지 않기
		isSelected[cnt] = false;
		makeSubSetSum2(cnt+1, pickCnt, sum, targetSum);
		
	}
}
