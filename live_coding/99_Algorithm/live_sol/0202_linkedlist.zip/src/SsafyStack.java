import java.util.EmptyStackException;

public class SsafyStack<E> implements IStack<E> {

	private Node<E> top; // head
	
	@Override
	public void push(E data) {
		// 새 노드 생성 후(헤드노드의 값을 새노드의 링크필드로..) 헤더노드의 값으로.
		top = new Node<E>(data, top);
	}

	@Override
	public E pop() {
		if(isEmpty()) throw new EmptyStackException();
		
		Node<E> popNode = top;
		top = popNode.link;		
		popNode.link = null;
		return popNode.data;
	}

	@Override
	public E peek() {
		if(isEmpty()) throw new EmptyStackException();
		
		return top.data;
	}

	@Override
	public boolean isEmpty() {
		return top == null;
	}

	@Override
	public int size() {
		int res = 0;
		for (Node<E> temp = top; temp != null ; temp = temp.link) {
			++res;
		}
		return res;
	}

	@Override
	public String toString() {
		return "SsafyStack [top=" + top + "]";
	}
	
}






