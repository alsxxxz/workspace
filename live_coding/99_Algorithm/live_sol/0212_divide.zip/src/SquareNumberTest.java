import java.util.Scanner;

public class SquareNumberTest {

	static long callCnt1, callCnt2;
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		int n = sc.nextInt();
		
		System.out.println(exp(x,n));
		System.out.println("수행횟수 : "+callCnt1);
		System.out.println(exp2(x,n));
		System.out.println("수행횟수 : "+callCnt2);
	}
	
	static long exp(long x,int n) {
		++callCnt1;
		if(n==1) return x;
		long y = exp(x, n/2);
		return y*y*(n%2==0?1:x);
	}
	
	static long exp2(long x,int n) {
		++callCnt2;
		if(n==1) return x;
		return x * exp2(x,n-1);
	}

}
