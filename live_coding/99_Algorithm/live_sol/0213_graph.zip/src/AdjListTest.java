import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class AdjListTest {

	// 연결리스트의 구성 요소 ==> 인접리스트 표현 
	static class Node{
		int vertex; // 인접정점 번호
		Node next; // 다음 노드에 대한 포인터역할
		
		public Node(int vertex, Node next) {
			super();
			this.vertex = vertex;
			this.next = next;
		}
		@Override
		public String toString() {
			return "Node [vertex=" + vertex + ", next=" + next + "]";
		}
	}
	
	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		int V = Integer.parseInt(in.readLine()); // 정점수
		int E = Integer.parseInt(in.readLine()); // 간선수
		
		Node adjList[] = new  Node[V];
		
		for (int i = 0; i < E; i++) {
			StringTokenizer st = new StringTokenizer(in.readLine()," ");
			int from = Integer.parseInt(st.nextToken());
			int to = Integer.parseInt(st.nextToken());
			
			// 무향 그래프
			adjList[from] = new Node(to,adjList[from]);
			adjList[to] = new Node(from,adjList[to]);
		}
		
		for (int i = 0; i < V; i++) {
			System.out.println(adjList[i]);
//			for (Node temp=adjList[i]; temp != null; temp = temp.next) {
//				
//			}
		}
	
		
		
		
		
		
		
	}

}
