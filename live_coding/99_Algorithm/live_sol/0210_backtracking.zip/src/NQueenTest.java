import java.util.Scanner;

public class NQueenTest {

	static int N, totalCnt;
	static boolean[] col, slash,bSlash;
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		totalCnt = 0;
		
		col = new boolean[N+1];
		slash = new boolean[2*N+1];
		bSlash = new boolean[2*N];
		
		setQueen(1);
		System.out.println(totalCnt);
	}
	
	static void setQueen(int row) {
		
		if(row>N) {
			++totalCnt;
			return;
		}
		
		for (int c = 1; c <= N; c++) {
			// 유망성 체크 : row행 c열에 두는것이 가능한지.
			if(col[c] || slash[row+c] || bSlash[(row-c)+N]) continue; // 가지치기
			
			col[c] = slash[row+c] = bSlash[(row-c)+N] = true;
			setQueen(row+1);
			col[c] = slash[row+c] = bSlash[(row-c)+N] = false; // 다른 선택지 시도 위해 상태 원복 
		}
		
	}

}










