import java.beans.Visibility;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.StringTokenizer;

public class AdjMatrixTest {
	
	static int V;
	static int adjMatrix[][];
	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		V = Integer.parseInt(in.readLine()); // 정점수
		int E = Integer.parseInt(in.readLine()); // 간선수
		
		adjMatrix = new int[V][V];
		
		for (int i = 0; i < E; i++) {
			StringTokenizer st = new StringTokenizer(in.readLine()," ");
			int from = Integer.parseInt(st.nextToken());
			int to = Integer.parseInt(st.nextToken());
			
			// 무향 그래프
			adjMatrix[to][from] = adjMatrix[from][to] = 1;
		}
		
		bfs(0);
		
//		dfs(0, new boolean[V]);
		
	}
	private static void bfs(int start) {
		// 큐생성
		Queue<Integer> queue = new ArrayDeque<>();
		// 방문관리 배열 생성
		boolean[] visited = new boolean[V];
		
		// 시작정점(너비0) 방문처리후 큐에 넣기
		visited[start] = true;
		queue.offer(start);
		
		// 큐에 탐색 정점이 있을때까지 반복
		while (!queue.isEmpty()) {
			// 탐색 대상 큐에서꺼내기
			int current = queue.poll();
			System.out.println((char)(current+65));
			
			// 탐색 대상의 인접정점 처리
			for (int i=0; i<V; ++i) {
				// 미방문 인접정점(current 너비+1)이면 방문처리후 큐에넣기
				if(adjMatrix[current][i] != 0 &&  !visited[i]) {
					visited[i] = true;
					queue.offer(i);
				}
			}
		}
		
	}
	
	private static void dfs(int current,boolean[] visited) {
		visited[current] = true;
		System.out.println((char)(current+65));
		
		// 탐색 대상의 인접정점 처리
		for (int i=0; i<V; ++i) {
			// 미방문 인접정점(current 너비+1)이면 큐에 넣기 
			if(adjMatrix[current][i] != 0 &&  !visited[i]) {
				dfs(i,visited);
			}
		}
	}
	
	
	
	
	
	
	
	
}
