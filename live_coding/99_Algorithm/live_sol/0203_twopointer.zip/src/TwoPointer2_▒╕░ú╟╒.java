import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

//>> 입력
//4 2
//1 1 1 1
//
//>> 출력
//3
//
//>> 입력
//10 5
//1 2 3 4 2 5 3 1 1 2
//
//>> 출력
//3

public class TwoPointer2_구간합 {

	public static void main(String[] args) throws IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		StringTokenizer st = new StringTokenizer(in.readLine(), " ");
		int N = Integer.parseInt(st.nextToken());
		int target = Integer.parseInt(st.nextToken());
		
		int[] arr = new int[N];
		st = new StringTokenizer(in.readLine(), " ");
		
		for (int i = 0; i < N; i++) {
			arr[i] = Integer.parseInt(st.nextToken());
		}
		
		int s,e,cnt,sum;//s : inclusive, e: exclusive
		s=e=cnt=sum=0;
		
		while(true) {
			if(sum >= target) {
				if(sum==target) ++cnt;
				sum -= arr[s++];
			}else if(e==N) { // 합이 목표합보다 작다면 e를 증가시켜야하는 상황인데 e가 더이상 뒤로 갈수 없는 상황 
				break;
			}else {// 합이 목표합보다 작다면 e를 증가시켜야하는 상황
				sum += arr[e++];
			}
		}
		System.out.println(cnt);
	}

}