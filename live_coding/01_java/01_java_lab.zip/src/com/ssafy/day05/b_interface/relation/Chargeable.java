package com.ssafy.day05.b_interface.relation;

public interface Chargeable {
    void charge();
}
