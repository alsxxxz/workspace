package com.ssafy.day01.a_basic;

public class Basic_07 {

    public static void main(String[] args) {
        byte b1 = 10;
        byte b2 = 20;
        // TODO: 다음에서 발생하는 오류를 읽고 원인을 말한 후 수정하시오. 
         // byte b3 = b1 + b2;

        int i1 = 10;
        long l1 = 20;
         // int i2 = i1 + l1;

         // float f1 = 10.0;

         // float f2 = f1 + 20.0;

        //END
    }
}
