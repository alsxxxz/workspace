package com.ssafy.day01.a_basic;

public class Basic_03 {
    public static void main(String[] args) {
        // TODO: 다음 코드의 실행 결과를 고민해보자. 
        int i1 = Integer.MAX_VALUE;

        int i2 = i1 + 1;

        System.out.println(i2);

        // END
    }
}
