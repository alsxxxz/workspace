package com.ssafy.day01.a_basic;

import java.util.ArrayList;

public class Basic_01 {

    public static void main(String[] args) {
        int i = 10;
        double d = 3.14;
        System.out.printf("i = %d, d = %f\n", i, d);
        // TODO: 01. 다음의 데이터를 저장하기 위한 변수들을 선언하고 값을 할당해보자.
        //  식사여부, 반번호, 신발사이즈, 갤럭시트라이폴드가격(360만원), 별간거리, 몸무게, 환율, 메달

        // END
    }
}
