package com.ssafy.day01.a_basic;

public class Basic_05 {
    public static void main(String[] args) {
        int i1 = Integer.MAX_VALUE;
        int i2 = i1 + 1;
        // TODO:i2의 값을 예상하고 출력해보세요.

        // END

        long l1 = i1 + 1;
        // TODO:l1의 값을 예상하고 출력해보세요.

        // END

        long l2 = (long) (i1 + 1);
        // TODO:l2의 값을 예상하고 출력해보세요.

        // END

        // TODO:l3의 값을 예상하고 출력해보세요.

        // END

        int i3 = 1000000 * 1000000 / 100000;
        int i4 = 1000000 / 100000 * 100000;
        // TODO:i3와i4의 값을 예상하고 출력해보세요.

        // END
    }
}
