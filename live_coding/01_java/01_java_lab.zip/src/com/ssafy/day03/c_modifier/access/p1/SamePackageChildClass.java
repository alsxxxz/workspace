package com.ssafy.day03.c_modifier.access.p1;

// TODO: Parent를 상속받고 Parent의 member들에 접근해보세요.
 public class SamePackageChildClass{

    // END
}
