package com.ssafy.edu;

import java.util.Arrays;

public class StudentMgrImpl implements StudentMgr {
	private StudentMgrImpl() {
		this.addStudent(new Student(1111, "김싸피", "15기", 27, "자바전공"));
		this.addStudent(new Student(1112, "박싸피", "15기", 26, "비전공 파이썬"));
		this.addStudent(new Student(1113, "홍싸피", "15기", 24, "데이터"));
		this.addStudent(new Student(1114, "김삼성", "15기", 29, "자바전공"));
	}
	
	public static StudentMgrImpl getInstance() {
		return null;
	};
	
	private static final int MAX_SIZE = 100;
	private Student[] students = new Student[MAX_SIZE];
	private int size;

	@Override
	public boolean addStudent(Student s) {

		return false;
	}

	@Override
	public Student[] search() {
		return null;
	}

	@Override
	public Student search(int num) throws NotFoundException {

		return null;
	}

	@Override
	public Student[] search(String name) {

		return null;
	}

	@Override
	public void update(int studentNum, String major) {


	}

	@Override
	public boolean delete(int studentNum) {

		return false;
	}

	@Override
	public boolean save() {

		return false;
	}

}
